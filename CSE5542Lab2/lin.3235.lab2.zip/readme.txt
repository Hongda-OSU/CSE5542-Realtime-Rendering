I did the extra credit 2
	Use the file plant2.txt
	Set Lab2.cpp line 355 to 0.01f